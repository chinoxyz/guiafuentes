double PI = acos(-1.0);
double PI = 4*atan(1.0);
